package com.Ebook.Entity;

public enum UserType {
AUTHOR,USER
}
